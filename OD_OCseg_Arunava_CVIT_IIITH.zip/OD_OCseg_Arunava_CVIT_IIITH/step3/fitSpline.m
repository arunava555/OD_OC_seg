function [res] = fitSpline( res_x,res_y, norm_sz )
%FITSPLINE Summary of this function goes here
%   Detailed explanation goes here

xpoints=(res_x)';ypoints=(res_y)';
xpoints(end+1)=xpoints(1);
ypoints(end+1)=ypoints(1);
%[uniqX,ia,ic]=unique(xpoints);
t=1:size(xpoints);
t1=1:.005:size(xpoints);
newX=int32(round(spline(t,xpoints,t1)));
newY=int32(round(spline(t,ypoints,t1)));

res=logical(zeros(norm_sz,norm_sz));
idx = sub2ind([norm_sz, norm_sz], newX, newY);
res(idx)=1;
res=imfill(res,'holes');

%figure, imshow(res,[])
end
