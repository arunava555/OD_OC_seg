function [ norm_map ] = get_normalized_ftrs( f ,inc, grd_sz, w, norm_sz)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%{
load pts.mat
f=double(f);

 cnt=0;
    norm_map=zeros(size(f));
    for th=1:inc:360
        cnt=cnt+1;
        
        tmp_idx=idx{th};
        prfl=f(idx{th});
        prfl=prfl./max(prfl);
        
        
        % Compute feature
            % create a mask(1D)
            mask=double([-1.*ones(1, grd_sz)  ones(1, grd_sz)]);
            % COrrelation
            ftr=conv(prfl,mask,'valid');
            ftr=ftr./grd_sz;
            % Normalize ftr
            ftr=ftr-min(ftr);
            ftr=ftr./max(ftr);
            % only keep the values within the ROI: min of cp and max of
            % OD:10 to 80: max of norm_sz is 9 .
            map=zeros(size(prfl));
            map(grd_sz:length(prfl)-grd_sz)=ftr;
            
  
        
        % put back the feature
        norm_map(idx{th})=map;
        
    end
    
    
norm_map1=norm_map;
clearvars -except norm_map1 f inc grd_sz w norm_sz
%}
    
%% NEW

load pts_nbr.mat
load pts.mat

f=double(f);


    norm_map=zeros(size(f));
    for th=1:inc:360
       
        
   
        
        % get the thick rectangular nbr
        prfl=double(zeros(2*w+1,ceil(norm_sz/2)));
        prfl(idx_99{th})=f(idx_nbr{th});
        prfl=prfl(:,2:end);
                                                                            prfl=prfl./max(prfl(:));
        
           % Compute feature
           % create mask
        mask=double([1.*ones(1, grd_sz)  -1.*ones(1, grd_sz)]);
        mask=repmat(mask,2*w+1,1);
        
            % COrrelation
            ftr=conv2(double(prfl),mask,'valid');
            mn=ceil(size(ftr,1)/2);
            ftr=ftr(mn,:);
                                                                            ftr=ftr./grd_sz;
            % Normalize ftr
            ftr=ftr-min(ftr);
            ftr=ftr./max(ftr);
            % only keep the values within the ROI: min of cp and max of
            % OD:10 to 80: max of norm_sz is 9 .
            map=zeros(1,size(prfl,2));
            map(grd_sz:length(prfl)-grd_sz)=ftr;
                                                                            % keep  profiles within 15:75 only
                                                                            %map(1:16)=-1;
                                                                            %map(76:end)=-1;
        
        % put back the feature
        norm_map(idx{th})=map;
        
    end
end

