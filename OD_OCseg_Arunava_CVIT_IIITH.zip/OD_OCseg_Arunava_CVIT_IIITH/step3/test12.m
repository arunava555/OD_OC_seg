function [res_od,res_cp]=test12(nm,lambda1,lambda2,lambda3,lambda4, lambda5)

 a=load (nm);
    f1_term=double(a.f1_term);
    pair_od=double(a.pair_od);
    pair_cp=double(a.pair_cp);
    pair_depth=double(a.pair_depth);
    c=int16(a.c1);norm_sz=int16(a.norm_sz);inc=int16(a.inc1);od_lbl=int16(a.od_lbl);cp_lbl=int16(a.cp_lbl);m=int16(a.m);n=int16(a.n);
    clear a
    
   f1_term(:,1:36)=f1_term(:,1:36).*lambda1; 
   f1_term(:,37:72)=f1_term(:,37:72).*lambda3;

        
    pair_od=pair_od.*lambda2;
    pair_cp=pair_cp.*lambda4;
    pair_depth=pair_depth.*lambda5;
    
    pair=cat(3,pair_od,pair_cp);
    pair=cat(3,pair,pair_depth);
      
    
    % Pairwise term
    pair=reshape(pair,(size(pair,1)*size(pair,2)),size(pair,3));
    
    % Graph edges
    
    % Run TRWS
    tmp_od=[[1:c-1; 2:c] [c;1]];
    tmp_cp=[[37:71; 38:72] [72; 37]];
    tmp_depth=[1:36; 37:72] ;
    graph=[tmp_od tmp_cp tmp_depth];
    clear tmp_od tmp_cp tmp_depth
   
    
    
    options = [];
options.num_max_iter = 200;
mu_unary_trws = mex_trws(f1_term, pair, double(graph-1), options);
[~, x] = max(mu_unary_trws, [], 1);

    

    
 load pts.mat
    % convert x to a contour and mask
            % convert x to contour
            % get position of each pt on profile
            c=0;
            cx=round(norm_sz/2);
            cy=round(norm_sz/2);
            
            res_od=zeros(norm_sz,norm_sz);
            res_cp=zeros(norm_sz,norm_sz);
            
            for th=1:inc:360
                c=c+1;
                
                
                tmp_od=x(c)+5;
                tmp_cp=x(c+36)+5;
                
                tmp9=tx{th};
                %res_x(c)=tmp9(x(c));
                res_xod(c)=tmp9(tmp_od);
                res_xcp(c)=tmp9(tmp_cp);
                
                tmp9=ty{th};
                %res_y(c)=tmp9(x(c));
                res_yod(c)=tmp9(tmp_od);
                res_ycp(c)=tmp9(tmp_cp);

            end
            % res_x and res_y are the points
            res_od = fitSpline( res_xod,res_yod, norm_sz );
            res_cp = fitSpline( res_xcp,res_ycp, norm_sz );
            
            
  res_od=imresize(res_od,[m n]);
 res_cp=imresize(res_cp,[m n]);
  res_od=res_od>0;
  res_cp=res_cp>0;
           
       %}     
                


end

