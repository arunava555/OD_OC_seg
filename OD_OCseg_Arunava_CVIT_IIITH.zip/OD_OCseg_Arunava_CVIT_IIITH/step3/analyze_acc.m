function []=analyze_acc(l1,l2,l3,l4,mat_dir,part_dir)

% get the final parameters
lambda1=1; % OD data
lambda2=l1; % OD smoothness
lambda3=l3; % Cp data term
lambda4=l2;% Cup smoothness 
lambda5=l4; % depth term pairwise



load([part_dir 'test.mat']);
for k=1:numel(tst_od)
    gg=[mat_dir num2str(k) '.mat'];
   [res_od{k},res_cp{k}]=test12(gg, lambda1,lambda2,lambda3,lambda4, lambda5 );
end


od_dir_tst=[pwd '/result/od/'];
cp_dir_tst=[pwd '/result/cup/'];
restore_full( res_od, res_cp,tst_r, tst_theta, tst_mnx1,  tst_mxx1, tst_mny1, tst_mxy1, tst_m1, tst_n1, tst_m, tst_n, tst_mnx, tst_mxx, tst_mny, tst_mxy,od_dir_tst, cp_dir_tst, tst_nm);

end

