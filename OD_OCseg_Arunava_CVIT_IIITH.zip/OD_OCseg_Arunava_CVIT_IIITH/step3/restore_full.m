function [ ] = restore_full( part_od, part_cp,set_r, set_theta, set_mnx1,  set_mxx1, set_mny1, set_mxy1, set_m1, set_n1, set_m, set_n, set_mnx, set_mxx, set_mny, set_mxy,od_dir, cp_dir, nm)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
for k=1:numel(part_od)
%k

    % 
    r=set_r{k};
    theta=set_theta{k};
   
    
    mnx1=set_mnx1{k};
    mxx1=set_mxx1{k};
    mny1=set_mny1{k};
    mxy1=set_mxy1{k};
    m1=set_m1{k};
    n1=set_n1{k};
    m=set_m{k};
    n=set_n{k};
    mnx=set_mnx{k};
    mxx=set_mxx{k};
    mny=set_mny{k};
    mxy=set_mxy{k};
    
    
    %%
    % Put od and od_msk back to the subI and submask respectively
        % Blank subI and submask
        submask_od=zeros(m1,n1);
        submask_cp=zeros(m1,n1);
        
        % Put back od
        submask_od(floor(mnx1):floor(mxx1),floor(mny1):floor(mxy1))=part_od{k};
        submask_cp(floor(mnx1):floor(mxx1),floor(mny1):floor(mxy1))=part_cp{k};
    % Invert rotation/reflection    
    if r==1
        submask_od=submask_od(:,end:-1:1);
        submask_cp=submask_cp(:,end:-1:1);
    end
    submask_od=imrotate(submask_od,-theta,'crop');
    submask_cp=imrotate(submask_cp,-theta,'crop');

    % make blank image for entire img
         mask_od=zeros(m,n);
         mask_cp=zeros(m,n);
    % Put back the submask and sub image
        mask_od(mnx:mxx,mny:mxy)=submask_od;
        mask_cp(mnx:mxx,mny:mxy)=submask_cp;
   


imwrite(mask_od,[od_dir nm{k}]);
imwrite(mask_cp,[cp_dir nm{k}]);


end

