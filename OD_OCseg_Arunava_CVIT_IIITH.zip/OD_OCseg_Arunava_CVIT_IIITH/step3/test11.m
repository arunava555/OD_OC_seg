function [unary_term, pair_od,pair_cup,pair_depth, c, norm_sz, inc, od_lbl, cp_lbl, m99, n99]=test11(model,depth,img,r,inc,w)
[m99, n99]=size(depth); 

depth=imresize(depth,[(2*r+1) (2*r+1)],'bicubic');
img=imresize(img,[(2*r+1) (2*r+1)],'bicubic');

addpath(genpath(pwd));
norm_sz=(2*r)+1;
grd_sz=15;
       


lbl=5:70;

[od_lbl, cp_lbl]=meshgrid(lbl,lbl);
od_lbl=od_lbl(:);
cp_lbl=cp_lbl(:);



    imgR=double(img(:,:,1));
    imgR=imgR-double(min(imgR(:)));

   
    
    [HSV] = rgb2hsv(img) ;
   
    
    imgV=double(HSV(:,:,3));
    imgV=imgV-double(min(imgV(:)));
    
    
    [YCbCr]=rgb2ycbcr(img);
    
    imgY=double(YCbCr(:,:,1));
    imgY=imgY-double(min(imgY(:)));
    
    imgCb=double(YCbCr(:,:,2));
    imgCb=imgCb-double(min(imgCb(:)));
    
    imgCr=double(YCbCr(:,:,3));
    imgCr=imgCr-double(min(imgCr(:)));



% gradient ftr on sectorwise profile
   R_map=get_normalized_ftrs( imgR ,inc, grd_sz,w,norm_sz);
   
    V_map=get_normalized_ftrs( imgV ,inc, grd_sz,w,norm_sz);

    Y_map=get_normalized_ftrs( imgY ,inc, grd_sz,w,norm_sz);
    Cb_map=get_normalized_ftrs( imgCb ,inc, grd_sz,w,norm_sz);
    Cr_map=get_normalized_ftrs( imgCr ,inc, grd_sz,w,norm_sz);
    
   
    load pts.mat
    
    % DATA TERM 
    cnt=0;
    unary_term=zeros(length(lbl),(360/inc)*2);
    pair_depth=zeros(length(lbl),length(lbl),(360/inc));
    
    for th=1:inc:360
        cnt=cnt+1;
      
      
       
       % Given od labels in od_lbl and cup labels in cp_lbl, compute ftrs
         
         % All profiles are defined upto the full length of the ROI
         tmp_idx=idx{th};
       
        depth_prfl=double(depth(tmp_idx));
        depth_prfl=depth_prfl-min(depth_prfl(:));
        depth_prfl=depth_prfl./max(depth_prfl(:));
        
       
        
        
        rmap_prfl=R_map(tmp_idx);
       
        vmap_prfl=V_map(tmp_idx);
       
        ymap_prfl=Y_map(tmp_idx);
        cbmap_prfl=Cb_map(tmp_idx);
        crmap_prfl=Cr_map(tmp_idx);
        
        
        
        % Feature 1: gradient of green channel at od boundary       
         tmp_ftr1=[rmap_prfl(lbl)' vmap_prfl(lbl)' ymap_prfl(lbl)' cbmap_prfl(lbl)' crmap_prfl(lbl)'];                 
         tmp_ftr5=[rmap_prfl(lbl)' vmap_prfl(lbl)' ymap_prfl(lbl)' cbmap_prfl(lbl)' crmap_prfl(lbl)']; 
                            
                                     
%% Compute Data Term
       % Data term 1:36 is for OD
       tod=pdf(model.od_unary{cnt},tmp_ftr1);
       tod=tod-min(tod);
       tod=tod./max(tod);
       
       % Data term 37:72 for CUP
       tcup=pdf(model.cp_unary{cnt},tmp_ftr5);
       tcup=tcup-min(tcup);
       tcup=tcup./max(tcup);
  

       
       unary_term(:,cnt)=(1-tod);
       unary_term(:,36+cnt)=(1-tcup);
  
 %% COMPUTE DEPTH BASED PAIRWISE TERM
tmp=zeros(length(lbl),length(lbl));
idx1=find(od_lbl<cp_lbl);

tmp(idx1)=999;% infinity

idx1=find(od_lbl>=cp_lbl);
 tmp_ftr3= abs(depth_prfl(od_lbl(idx1))-depth_prfl(cp_lbl(idx1)))';


 t = pdf(model.pair_depth{cnt},tmp_ftr3);
 t=t-min(t);
 t=t./max(t);
 
tmp(idx1)=1-t;% 
tmp=tmp';

 
 pair_depth(:,:,cnt)=tmp;
 
    end 
   
   
     clearvars -except inc  model lambda unary_term r norm_sz inc od_lbl cp_lbl lbl pair_depth m99 n99
    
    
       %% PAIRWISE TERM FOR OD and CUP
       
       
    c=0;   
     pair_cup=zeros(length(lbl),length(lbl),36);
     pair_od=zeros(length(lbl),length(lbl),36);
    % Pairwise term: C by C by ne=r by r by 360
    % for each node ie sector
    for th=1:inc:360
        %sel grd distrbution parameters
        c=c+1;
        
        % OD, CP PAIRWISE TERM: Both are exactly same but with diff GMM
        % models
        
        [od_lbl_prev,od_lbl_next]=meshgrid(lbl,lbl);
        od_lbl_prev=od_lbl_prev(:);
        od_lbl_next=od_lbl_next(:);
        ftr1=abs(od_lbl_next-od_lbl_prev);
        
        %compute pair od
        t=pdf(model.binary_od{c},ftr1);
        t=t-min(t(:));
        t=t./max(t(:));
        t=1-t;
       
        t=reshape(t,length(lbl),length(lbl));
        pair_od(:,:,c)=t;
        
        % compute pair cp
        t=pdf(model.binary_cp{c},ftr1);
        t=t-min(t(:));
        t=t./max(t(:));
        t=1-t;
        
        t=reshape(t,length(lbl),length(lbl));
        pair_cup(:,:,c)=t;
        
        clear t
    end
    
    
    clearvars -except unary_term pair_depth pair_cup pair_od c norm_sz inc od_lbl cp_lbl lbl m99 n99
    

                


end

