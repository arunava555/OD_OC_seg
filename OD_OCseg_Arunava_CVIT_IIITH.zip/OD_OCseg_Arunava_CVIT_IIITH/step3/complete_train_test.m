clear all
clc
addpath([pwd '/trws_64bit/matlab/']);
addpath(genpath([pwd '/../step1/']))
addpath(genpath([pwd '/../step2/']))
 inc=10;
 norm_sz=201;
 w=15;
%
load('model.mat');
load('test.mat');
load('depth.mat');
%% call cup testing
mat_dir=[pwd '/energy_mat/'];
for k=1:numel(tst_od)
    k
    depth=depth_tst_img{k};
    od=tst_od{k};
    clearvars -except model depth od vss r inc lambda k  mat_dir w depth_tst_img tst_od 
   [f1_term, pair_od, pair_cp, pair_depth, c1, norm_sz,inc1, od_lbl, cp_lbl, m, n]=test11(model, depth,od, r, inc,w);
   save([mat_dir num2str(k) '.mat'],'f1_term','pair_od','pair_cp','pair_depth','c1','norm_sz','inc1','od_lbl','cp_lbl','m','n');
end
%}
%%
mat_dir=[pwd '/energy_mat/'];
part_dir=[pwd '/../step1/'];% where test.mat is presnt
tst_gt_dir='/home/arunava/OD_OCseg_Arunava_CVIT_IIITH/Drishti-GS1_files/Drishti-GS1_files/Test/Test_GT/';
% The first 4 parameters in the function are relative weights (comments within analyze_acc.mat )
% These parameters need to be tuned for different datasets in orders of 10
analyze_acc(1,1,10^-1,10^-1,mat_dir,part_dir);
