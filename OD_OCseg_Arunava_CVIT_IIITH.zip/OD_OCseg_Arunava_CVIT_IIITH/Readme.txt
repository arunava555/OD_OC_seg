Author: Arunava Chakravarty
Supervisor: Prof. Jayanthi Sivaswamy
Center for Visual Information Technology, IIIT-Hyderabad (https://cvit.iiit.ac.in/projects/mip/)
-----------------------------------------------------------------------------------------------------------------------------------
We are releasing a Matlab code for segmentation of the Optic Disc and Cup in retinal color fundus images.
The code is freely available to allow other researchers to develop, compare and benchmark their algorithms. 
This code is not clinically approved and released for non-commerical research purposes only.

The code is primarily based on the following papers. Please cite them if you find the code useful.

[1] Chakravarty A., Sivaswamy J. Coupled Sparse Dictionary for Depth-Based Cup Segmentation from Single
 Color Fundus Image. In: Medical Image Computing and Computer-Assisted Intervention MICCAI 2014. LNCS, vol 8673. Springer

[2] Arunava Chakravarty, Jayanthi Sivaswamy, Joint optic disc and cup boundary extraction from monocular fundus images, 
In Computer Methods and Programs in Biomedicine, Volume 147, 2017, Pages 51-61
(http://www.sciencedirect.com/science/article/pii/S0169260717301128)

##################################################################################################
Instructions on how to run the code: Note only test part of the code is provided
##################################################################################################
For demo, download and place the DRISHTI-GS1 dataset at "........./OD_OCseg_Arunava_CVIT_IIITH/".
DRISHTI-GS1 is publicly available at: 
http://cvit.iiit.ac.in/projects/mip/drishti-gs/mip-dataset2/Home.php
-------------------------------------------------------------------------------------------------
Step1: Preprocessing step: Prepare fundus images for training and testing.

Run: step1_od_localize1.m within the "step1" folder.
It is the main script that just calls "find_od2" and saves results.
The results are saved as mat files (test.mat)

Additional Comments:
The find_od2.m calls a function "od_localization" for extracting ROI. 
This is based on Hough transform but currently fine-tuned to work for DRISHTI-GS only.
Appropriate localization codes should be used in this place for different datasets. 


find_od2.m performs OD localization and rotation to align the OD.  [theta, r]=compute_align1(od);
compute_align1(od): currently doesnot work that well. There is room for improvement here.
----------------------------------------------------------------------------------------------------
STEP 2: Estimate the depth using coupled sparse coding based regression. Only test code is provided
Run: step2_estimate_depth.m within the folder named "step2.m"
The output is the depth map which is saved in a mat file "depth.mat"
-----------------------------------------------------------------------------------------------------
STEP3: Jointly segment OD and OC using the CRF model. Only test code is provided
Run : complete_train_test.m within the folder named "step3"
analyze_acc saves results inside the result folder
-----------------------------------------------------------------------------------------------------

