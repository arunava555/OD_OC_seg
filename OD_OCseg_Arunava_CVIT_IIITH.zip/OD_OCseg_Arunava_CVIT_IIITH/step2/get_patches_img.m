function  [tt]=get_patches_img(ftr_chn,nc)

    d_sz=size(ftr_chn,3);
    tt=[];
    for d=1:d_sz
       % for each ftr channel in image
       t=ftr_chn(:,:,d);
       X=im2col(t,[8 8],'sliding');
      
       if d==1
          % instead of values, we need the histogram
          % nc is the no of bins of histogram
          for k=1:size(X,2)
             tmp=X(:,k);
             tmp7= hist(tmp,[1:nc]);
            % tmp7=tmp7./max(tmp7);
             X1(:,k)=tmp7;
          end
          clear X
           X=X1;
           clear X1
       end
       
       tt=[tt; X];
    end
   % tt=uint8(tt);
end