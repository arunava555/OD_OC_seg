function [  depth_ftr_chn ] = comp_depth_ftr(tmp_depth )
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here

%{
    depth_ftr_chn(:,:,1)=my_normalize(double(tmp_depth));
    [dx, dy]=gradient(tmp_depth);
    depth_ftr_chn(:,:,2)=my_normalize(dx);
    depth_ftr_chn(:,:,3)=my_normalize(dy);
%}
tmp_depth=double(tmp_depth);
    depth_ftr_chn(:,:,1)=tmp_depth;
  [dx, dy]=gradient(tmp_depth);
    
    
    % map dx and dy to [0,255]

       
   depth_ftr_chn(:,:,2)=dx;
   depth_ftr_chn(:,:,3)=dy;
end

