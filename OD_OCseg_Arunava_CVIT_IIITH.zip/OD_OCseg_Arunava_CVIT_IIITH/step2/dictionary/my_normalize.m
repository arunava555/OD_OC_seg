function [ a ] = my_normalize( a )
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here
a=double(a);
a=a-min(a(:));
a=a./max(a(:));
a=a+1;

end

