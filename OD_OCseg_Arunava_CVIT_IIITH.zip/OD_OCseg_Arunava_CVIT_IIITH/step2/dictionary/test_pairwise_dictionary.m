function [depth_ftr]=test_pairwise_dictionary(model,img_ftr)

% Initialize depth_ftr
    % Find alpha for img_ftr
    alpha_img=mexLasso(img_ftr,model.img_basis,model.param);
    % Find depth_ftr using above alpha
    
    
    %alpha_depth=model.W_img*full(alpha_img);
    alpha_depth=full(alpha_img);

    
    %depth_ftr=model.depth_basis*alpha_depth;
                

                
%{                
% Alternative updation of alpha_img and alpha_depth
for t=1:5
            %D = [Dl; par.sqrtmu * Wl];
        D=[model.img_basis; sqrt(model.par.mu)*model.W_img];
        %Y = [Xl; par.sqrtmu * full(Alphah)];
        Y=[img_ftr;sqrt( model.par.mu)*full(alpha_depth)];
        %Alphal = mexLasso(Y, D,param);
        alpha_img=mexLasso(Y,D,model.param);
        clear Y D;        
        %D = [Dh; par.sqrtmu * Wh];
        D=[model.depth_basis;sqrt( model.par.mu)*model.W_depth];  
        %Y = [Xh; par.sqrtmu * full(Alphal)];
        Y=[depth_ftr; sqrt(model.par.mu) * full(alpha_img)];
        %Alphah = full(mexLasso(Y, D,param));
        alpha_depth=full(mexLasso(Y,D,model.param));
        clear Y D;
        %Xh = Dh * Alphah;
                    depth_ftr=model.depth_basis*alpha_depth;

end
                
%}


% Final depth_ftr
depth_ftr=model.depth_basis*alpha_depth;
%load debug.mat
end


