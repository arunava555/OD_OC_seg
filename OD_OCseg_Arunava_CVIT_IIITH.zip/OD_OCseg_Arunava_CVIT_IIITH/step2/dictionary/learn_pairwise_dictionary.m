function [model]=learn_pairwise_dictionary(img_ftr, depth_ftr)

% the features are: dimensionality by no of samples


% initialize coupled dictionaries and coefficients using concatenated space
% as in Vjay's paper. Initialize W to 1.
img_ftr=double(img_ftr);
depth_ftr=double(depth_ftr);
    %Step1: Concatenate the input spaces
    ftr=[img_ftr; depth_ftr];
    %Step 2: dictionary parameters
    param.K=1200;% size of dictionary
                        param.lambda=.6;
                        %param.lambda=.001;
    param.iter=800;% max number of iterations to run
   % param.numThreads=5;
    param.batchsize=600;
    param.approx=0;
    %Step3: Learn the dictionary
    [D model]=mexTrainDL(ftr,param);
    % Step 4: Decouple the basis
    sz1=size(img_ftr,1);
    img_basis=D(1:sz1,:);
    depth_basis=D(sz1+1:end,:);
    
    
    %{
    %Step5: Apply dictionary on training image itself to get the coeffcients
    param.approx=0;
    % alpha is the new dimensional ftr (may be more or less depending on no of dictionaries)
    alpha=mexLasso(ftr,D,param);
    alpha=full(alpha);
    % step 6: Initialize W as 1.
    W=eye(param.K);
    W_depth=W;W_img=W;
% Run SemiCoupled dictionary learning algo.
                par.rho=5e-2;
                par.lambda1=0.04;
                par.lambda2=0.04;
    par.mu=0.01;
    par.nu=0.1;
    par.t0=5;
    par.nIter=500;% max iterations
    par.epsilon=5e-3;%threshold change in objective in successive iteration to stop
    par.K=param.K;
    [alpha_depth, alpha_img, depth_ftr, img_ftr, depth_basis, img_basis, W_depth, W_img, f] = coupled_DL(alpha, alpha, depth_ftr, img_ftr, depth_basis, img_basis, W_depth, W_img, par);
    % f can be thought of as the value of the optimization function(which is minimized)
    %}
    
    
% Update model parameters
model.img_basis=img_basis;
model.depth_basis=depth_basis;
model.param=param;




%{
model.W_depth=W_depth;
model.W_img=W_img;
model.par=par;
%}
end

