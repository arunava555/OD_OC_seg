function [C] = learn_texture_words(train_img,nc,n1,th)
%addpath('/home/arunava/depth_map/code/v2/texture/compute_ftr_space/');
train_ftr=[];

% number of points for clustering:psz
psz=900;
sz=size(train_img,1);

for k=1:sz
        f=train_img{k};
        [ res ] = apply_gabor( f,n1,th);
        
    % select n pts randomly for clustering
        [m,n,~]=size(f);
        idx=randi((m*n),[1 psz]);
        [tx, ty]=ind2sub(size(f),idx);
        for k1=1:length(idx)
            a=res(tx(k1),ty(k1),:);
            a=squeeze(a);
            a=a';
            train_ftr=[train_ftr; a];
            clear a
        end
clear res
end
% apply clustering and save the cluster centres
options = statset('MaxIter',900);
[~,C] = kmeans(train_ftr,nc,'options',options);

end
