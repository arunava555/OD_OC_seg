function [] = call_gabor(s,mx_scl,th)
% create  gabor filter and save in mat files
%s, s*k, s*k^2, s*k^3;   k=1.6 , only parameter is number of scales and s
% Aspect Ratio=.5;  Sigma/lambda=.56, Theta: 0:20:180; Phi: 2 values
% max  scales=3/5/7
k=1.6;

for n=1:mx_scl
sigma=s*(k^(n-1));
sz=round(5*sigma);
 if mod(sz,2)==0, sz=sz+1;end
[ gb_even, gb_odd ] = create_gabor( sigma,sz,th );
save([pwd '/gabor_ftr/g' num2str(n) '.mat'],'gb_even','gb_odd');
%save([pwd '/g' num2str(n) '.mat'],'gb_even','gb_odd');
clear h gb_even gb_odd
end

