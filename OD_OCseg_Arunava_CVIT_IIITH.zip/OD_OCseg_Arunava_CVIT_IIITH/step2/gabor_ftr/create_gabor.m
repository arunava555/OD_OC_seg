function [ gb_even, gb_odd ] = create_gabor( sigma,sz,th )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

% aspect ratio
gamma=.5;
lambda=sigma/.56;
th_inc=floor(180/th);
c=1;
for theta=0:th_inc:180
    
    sigma_x = sigma;
    sigma_y = sigma/gamma;
    
    [x y]=meshgrid(-fix(sz/2):fix(sz/2),fix(sz/2):-1:fix(-sz/2));
   %[x_theta y_theta]=meshgrid(-fix(sz/2):fix(sz/2),fix(sz/2):-1:fix(-sz/2));
    % Rotation 
    x_theta=x*cosd(theta)+y*sind(theta);
    y_theta=-x*sind(theta)+y*cosd(theta);
 
    even_filter=exp(-0.5*(x_theta.^2/sigma_x^2+y_theta.^2/sigma_y^2)).*cos(2*pi/lambda*x_theta);
    odd_filter=exp(-0.5*(x_theta.^2/sigma_x^2+y_theta.^2/sigma_y^2)).*sin(2*pi/lambda*x_theta);
    
    gb_even(:,:,c)=even_filter;
    gb_odd(:,:,c)=odd_filter;
    clear even_filter odd_filter
c=c+1;
end

   