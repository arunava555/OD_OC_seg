function [ texture_img ] = estimate_texture(train_img,C,mx_scl,th  )

for k=1:length(train_img)
    tmp_img=train_img{k};
    
        res=apply_gabor( tmp_img,mx_scl,th);
        clearvars -except res tmp_img k train_img C th mx_scl texture_img
        % Convert each pixel to a t4exture word
        [m, n, p]=size(res);
        Y=reshape(res,[m*n, p]);
        IDX = knnsearch(C,Y);
        texture_img{k}=uint8(reshape(IDX,[m,n]));

end
end

