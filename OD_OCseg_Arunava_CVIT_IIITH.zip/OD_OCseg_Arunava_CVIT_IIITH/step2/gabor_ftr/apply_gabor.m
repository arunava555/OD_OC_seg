function [ res ] = apply_gabor( f,n,theta)
% f the img, n : no of scales
% hi
if length(size(f))==3
%f=rgb2gray(f);
f=f(:,:,2);
end
f=single(f);

[m1,n1]=size(f);
res=(zeros(m1,n1,(theta*n)));
c=0;
for k=1:n
   % load the kernel
   load(['g' num2str(k) '.mat']);   
   for th=1:theta
       c=c+1;
      h1=gb_even(:,:,th);
      h2=gb_odd(:,:,th);
      g1=imfilter(f,h1,'conv','same','replicate');
      g2=imfilter(f,h2,'conv','same','replicate');
      g=sqrt(g1.^2+g2.^2);
      res(:,:,c)=g;
      clear h1 h2 g1 g2 g
   end
end

cnt=0;
for k=1:c
t=res(:,:,k);
[dx dy]=gradient(t);
[dxx dxy]=gradient(dx);
[dyx dyy]=gradient(dy);
cnt=cnt+1;
tmp(:,:,cnt)=dx;
cnt=cnt+1;
tmp(:,:,cnt)=dy;
cnt=cnt+1;
tmp(:,:,cnt)=dxx;
cnt=cnt+1;
tmp(:,:,cnt)=dyy;
cnt=cnt+1;
tmp(:,:,cnt)=dxy;
                        %cnt=cnt+1;
                        %tmp(:,:,cnt)=t;
end
clear res
res=tmp;
clear tmp;
end

