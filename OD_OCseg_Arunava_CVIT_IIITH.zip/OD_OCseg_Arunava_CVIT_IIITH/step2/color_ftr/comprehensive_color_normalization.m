function [tmp]=comprehensive_color_normalization(f)

flag=1;
cnt=0;
r=double(f(:,:,1));
g=double(f(:,:,2));
b=double(f(:,:,3));

%{

while flag~=0 & cnt<=20
    cnt=cnt+1
    % Normalize 
    s=r+g+b;
    rnew=r./s;
    gnew=g./s;
    bnew=b./s;
    
    rmean=mean(rnew(:));
    gmean=mean(gnew(:));
    bmean=mean(bnew(:));
    
    rnew=rnew./rmean;
    gnew=gnew./gmean;
    bnew=bnew./bmean;
    
    flag=abs(r-rnew)+abs(g-gnew)+abs(b-bnew);
    r=rnew;g=gnew;b=bnew;
    
end

tmp(:,:,1)=r;
tmp(:,:,2)=g;
tmp(:,:,3)=b;

%}


    s=r+g+b;
    tmp(:,:,1)=r./s;
    tmp(:,:,2)=g./s;
    tmp(:,:,3)=b./s;

end

