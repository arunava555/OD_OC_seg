function  [g]=comp_color(train_img)

     for k=1:length(train_img)
         f=double(train_img{k});
         % remove luminance and retain color only
         g{k}=comprehensive_color_normalization(f);
     end

end

