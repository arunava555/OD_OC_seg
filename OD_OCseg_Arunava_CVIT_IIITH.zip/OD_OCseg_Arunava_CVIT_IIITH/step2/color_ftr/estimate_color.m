function [depth_color]=estimate_color(g,gmm)
 
lambda=0.001;
Sc=zeros(256,256);
    for x=1:256
        for y=1:256
            if(x==y)
       Sc(x,y)= 0;
            else
               Sc(x,y)=lambda*abs(x-y); 
            end
        end
    end
clearvars -except g gmm lambda Sc    
for k1=1:length(g)
    k1
    img=g{k1}; 
    img1=img(:,:,1);
    img2=img(:,:,2);
    img3=img(:,:,3);
    
    
    [m, n]=size(img1);
    img1=img1(:);
    img2=img2(:);
    img3=img3(:);
    tmp_ftr=[img1 img2 img3];
    for d=1:256
       tmp = pdf(gmm{d},tmp_ftr);      
        
        y(:,d)=tmp;
        tmp=y(:,d);
        tmp=tmp-min(tmp);
        tmp=tmp./max(tmp);
        tmp=1-tmp;
        Dc(:,:,d)=reshape(tmp,m,n);
    end
    y=single(y);
    
    
    % DATA TERM ONLY
    [C, I]=max(y,[],2);
    res=reshape(I,m,n);
    res=res-1;
    %imshow(res,[])
    %drawnow
    
 clear d   idx img img1 img2 img3 tmp_ftr y
    
    %{

   [gch] = GraphCut('open', Dc, Sc);
   [gch] = GraphCut('set', gch, res);
   [gch labels] = GraphCut('swap', gch,25);
    depth_color{k1}=uint8(labels);
%}    
 
                h = fspecial('gaussian', [5 5],4);
                res = imfilter(res,h,'replicate');
                
                depth_color{k1}=res;
    
    clear C Dc I gch labels m n res tmp
    
end

end

