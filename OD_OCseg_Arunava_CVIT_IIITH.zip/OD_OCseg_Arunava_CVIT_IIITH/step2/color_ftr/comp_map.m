function [map]=comp_map(f,threshold)


f=f-min(f(:));
f=f./max(f(:));
f=f.*255;
f=uint8(f);
map=f<threshold;


end

