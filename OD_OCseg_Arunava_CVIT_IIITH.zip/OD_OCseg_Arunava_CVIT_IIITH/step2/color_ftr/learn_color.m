function [gmm, g]=learn_color(g, train_depth)



     
     for d=1:256
        d
        tmp_ftr=[];
        % find all pixel  colors with that depth
        for k=1:length(train_depth)% each image
            tmp_depth=train_depth{k};
            tmp=g{k};
            tmp1=tmp(:,:,1);
            tmp2=tmp(:,:,2);
            tmp3=tmp(:,:,3);
       
            idx=find(tmp_depth==(d-1));
            tmp_a=tmp1(idx);
            tmp_b=tmp2(idx);
            tmp_c=tmp3(idx);
            tmp_ftr=[tmp_ftr; [tmp_a tmp_b tmp_c]];
        end
        % learn a GMM here
        options = statset('MaxIter',1000);
        for k = 1:6
            obj{k} = gmdistribution.fit(tmp_ftr,k,'Start','randSample','Replicates',5,'CovType','full','SharedCov',false,'Regularize',.001,'Options',options);
            AIC(k)= obj{k}.AIC;
        end
        [minAIC,numComponents] = min(AIC);
        numComponents
        model = obj{numComponents};
        % save the GMM model
        gmm{d}=model;
    end

end

