function [res]=remove_vessels(train_img)

    for k=1:length(train_img)
        k
        f=double(train_img{k});
 
        % Supress the vessels
        % obtain vessel map [0,1]
        v= vesselFactortoSuppress_disk(f, 6);% second arg gives max thickness of vessel
        % Threshold vessel map
        v_mask=v>.11;
        b_mask=imcomplement(v_mask);
        % inpaint vessel map
        f(:,:,1) = inpaint( f(:,:,1),b_mask );
        f(:,:,2) = inpaint( f(:,:,2),b_mask );
        f(:,:,3) = inpaint( f(:,:,3),b_mask );
        res{k}=f;
   
    end
        
    end


