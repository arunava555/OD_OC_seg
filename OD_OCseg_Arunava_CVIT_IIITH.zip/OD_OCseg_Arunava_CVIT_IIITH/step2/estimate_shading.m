function [depth_shading] = estimate_shading(train_img)
th=225; 
for k1=1:length(train_img)
    k1
    f=train_img{k1};   
    
    
    R=double(f(:,:,1));
    G=double(f(:,:,2));
    B=double(f(:,:,3));

    
    r=R./(R+G+B);
    g=G./(R+G+B);
    I=(R+G+B)./3;
    logI=log(I+1);

    [rx, ry]=gradient(r);
    [gx, gy]=gradient(g);
    cx=max(rx,gx);
    cy=max(ry,gy);
    
    [dx, dy]=gradient(logI);

    % smooth all
    cx= medfilt2(cx, [3 3]);
    cy= medfilt2(cy, [3 3]);
    dx= medfilt2(dx, [3 3]);
    dy= medfilt2(dy, [3 3]);
    
    mapx=comp_map(cx,th);
    mapy=comp_map(cy,th);

    dx=dx.*mapx;
    dy=dy.*mapy;
    
    g= intgrad2(dx,dy);
    h=fspecial('gaussian',[5 5],1);
    g = imfilter(g,h,'conv','same','replicate');
    g=exp(g);

    %g=(R+G+B)./3;
    % Estimate constant albedo and illumination position
% NOrmalize[0,1]
g=g-min(g(:));
g=g./max(g(:));
% avg intensity
Mu1=mean(g(:));
% square avg intensity
Mu2=mean(mean(g.^2));
% compute gradient
[Ex,Ey] = gradient(g);
% normalize the gradients toExy = sqrt(Ex.^2 + Ey.^2);
Exy = sqrt(Ex.^2 + Ey.^2);
nEx = Ex ./(Exy + eps); 
nEy = Ey ./(Exy + eps);
% computing the average of the normalized gradients
avgEx = mean(Ex(:));
avgEy = mean(Ey(:));

gamma = sqrt((6 *(pi^2)* Mu2) - (48 * (Mu1^2)));
albedo = gamma/pi;

slant = acos((4*Mu1)/gamma);

% estimating the tilt
tilt = atan(avgEy/avgEx);

if tilt < 0
tilt = tilt + pi;
end

I = [cos(tilt)*sin(slant) sin(tilt)*sin(slant) cos(slant)];


% Estimate depth map

% INITIALIZATION
% bring g to [0,255]
E=g.*255;
[M,N] = size(E);

p = zeros(M,N);
q = zeros(M,N);

Z = zeros(M,N);



Z_x = zeros(M,N);
Z_y = zeros(M,N);

maxIter = 200;

% the normalized illumination
ix = cos(tilt) * tan(slant);
iy = sin(tilt) * tan(slant);

% OPTIMIZATION
for k= 1 : maxIter
    R=(cos(slant) + p .* cos(tilt)*sin(slant)+ q .*sin(tilt)*sin(slant))./sqrt(1 + p.^2 + q.^2);
    R = max(0,R);
    f = E - R;
    df_dZ =(p+q).*(ix*p + iy*q + 1)./(sqrt((1 + p.^2 + q.^2).^3)*sqrt(1 + ix^2 + iy^2))-(ix+iy)./(sqrt(1 + p.^2 + q.^2)*sqrt(1 + ix^2 + iy^2));
    Z = Z - f./(df_dZ + eps);
    Z_x(2:M,:) = Z(1:M-1,:);
    Z_y(:,2:N) = Z(:,1:N-1);
    Z_x(2:M,:) = Z(1:M-1,:);
    Z_y(:,2:N) = Z(:,1:N-1);
    p= Z - Z_x;
    q= Z - Z_y;
end
Z = medfilt2(abs(Z),[21 21]);
mx=max(Z(:));
Z=mx-Z;


% Normalize Z
Z=Z-min(Z(:));
Z=Z./max(Z(:));
Z=Z.*255;
Z=uint8(Z);
depth_shading{k1}=Z;
end

end

