function [depth]=depth_test(model,test_img)


% compute ftr channels for the input image
nc=model.nc;
test{1}=test_img;
% compute tmp_clr
test_img2=remove_vessels(test);
g=comp_color(test_img2);
gmm=model.gmm;
tmp_clr1=estimate_color(g,gmm);
tmp_clr=tmp_clr1{1};
clear tmp_clr1
% compute tmp_shd
tmp_shd1=estimate_shading(test);
tmp_shd=tmp_shd1{1};
clear tmp_shd1
% compute tmp_txt
tmp_txt1= estimate_texture(test,model.C,model.mx_scl,model.th  );
tmp_txt=tmp_txt1{1};
clear tmp_txt1

img_ftr_chn = comp_img_ftr( tmp_clr, tmp_shd, tmp_txt);
img_ftr=get_patches_img(img_ftr_chn,nc); 


N=size(img_ftr,2);
% Normalize 
img_ftr=single(img_ftr);

img_ftr=img_ftr';
img_ftr=img_ftr-repmat(model.basis.norm_mn_img, [size(img_ftr,1) 1]);
                        img_ftr=img_ftr./repmat(model.basis.norm_img, [size(img_ftr,1) 1]);
img_ftr=img_ftr';
img_ftr=double(img_ftr);



% CCA using learnt basis to obtain transformed ftr space for img_ftr
%U = (img_ftr'-repmat(mean(img_ftr'),size(img_ftr,2),1))*A;
U = (img_ftr'-repmat(model.basis.cca_mn_img,size(img_ftr,2),1))*model.basis.A;
tmp=img_ftr;
img_ftr=U';



% Test pairwise dictionary
depth_ftr=test_pairwise_dictionary(model.basis,img_ftr);


% apply inverse CCA on depth_ftr
V=depth_ftr';
depth_ftr=((V*pinv(model.basis.B))+repmat(model.basis.cca_mn_depth,size(tmp,2),1))';



% Invert the normalization of depth using parameters used during training
depth_ftr=depth_ftr';
            depth_ftr=depth_ftr.*repmat(model.basis.norm_depth, [size(depth_ftr,1) 1]);
depth_ftr=depth_ftr+repmat(model.basis.norm_mn_depth, [size(depth_ftr,1) 1]);
depth_ftr=depth_ftr';

% depth_ftr has 2 channels dx and dy merge the patches separately
sz=size(depth_ftr,1);
%{
dx=depth_ftr(1:sz/2,:);
dy=depth_ftr(sz/2+1:end,:);
depth_dx = mergePatch(dx, 8, 8, size(test_img,1),size(test_img,2)) ;
depth_dy = mergePatch(dy, 8, 8, size(test_img,1),size(test_img,2)) ;
depth=intgrad2(depth_dx,depth_dy);
%}
                                            %depth=mergePatch(depth_ftr, 8, 8, size(test_img,1),size(test_img,2)) ;

                                            
            d=depth_ftr(1:sz/3,:);
            d = mergePatch(d, 8, 8, size(test_img,1),size(test_img,2)) ;
            dx=depth_ftr(sz/3+1:2*sz/3,:);
            dy=depth_ftr((2*sz/3)+1:end,:);
         % convert depth ftr back to depth image by merging patches
         depth_dx = mergePatch(dx, 8, 8, size(test_img,1),size(test_img,2)) ;
         depth_dy = mergePatch(dy, 8, 8, size(test_img,1),size(test_img,2)) ;
        depth_img=intgrad2(depth_dx,depth_dy);
        depth=(depth_img+d)/2;

 
           
         
end


