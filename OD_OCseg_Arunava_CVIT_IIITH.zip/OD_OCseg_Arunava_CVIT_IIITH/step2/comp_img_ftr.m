function [ img_ftr_chn ] = comp_img_ftr( tmp_clr, tmp_shd, tmp_txt)
%UNTITLED10 Summary of this function goes here
%   Detailed explanation goes here
tmp_clr=double(tmp_clr);
tmp_shd=double(tmp_shd);

    img_ftr_chn(:,:,1)=(double(tmp_txt));    
   
    
   img_ftr_chn(:,:,2)=tmp_clr;
   [clx, cly]=gradient((tmp_clr));
   %img_ftr_chn(:,:,3)=(clx);
   %img_ftr_chn(:,:,4)=(cly);
   
    
    img_ftr_chn(:,:,3)=tmp_shd;
    [sx, sy]=gradient((tmp_shd));
    img_ftr_chn(:,:,4)=(sx);
    img_ftr_chn(:,:,5)=(sy);
    

end

