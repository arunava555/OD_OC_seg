clear all
clc
addpath(genpath(pwd))
load('/home/arunava/OD_OCseg_Arunava_CVIT_IIITH/step1/test.mat')
load model.mat
clearvars -except tst_od model
sz=93;
for k=1:numel(tst_od)
        k
        % read img
        img=tst_od{k};
        % Resize img
        [m, n, ~]=size(img);
        img=imresize(img,[sz sz]);
        % call depth
        tmp=depth_test(model,img);
        % resize back
        depth_tst_img{k}=imresize(tmp,[m n],'bicubic');
end
save('depth.mat','depth_tst_img');
