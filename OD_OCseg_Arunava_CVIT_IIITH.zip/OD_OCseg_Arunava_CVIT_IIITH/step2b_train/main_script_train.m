clear all
clc

 %% TRAINING
load train.mat
load depth.mat
clearvars -except trn_od trn_od_gt2 trn_od_gt1 depth_trn_img inc
% outputs
% call cup training
 inc=10;
 norm_sz=201;
 w=15;


 create_prfl( norm_sz,w );
[ model, cx, cy, r ] = cup_train( trn_od,cup_gt, od_gt ,depth_trn_img, inc, norm_sz,w );
save('model.mat','model','r','inc');
clearvars -except w

