function [model] = train1(train_depth,train_cupgt, roi,train_odgt,cx,cy,r,inc,w)
options = statset('MaxIter',1000);
load pts.mat

c=0;
for th=1:inc:360
    c=c+1;
    ftr{c}=[];
end
c=0;

for k=1:numel(train_depth)
    
    % Read current depth, cup and od images
    cupgt=train_cupgt{k};
    depth_img=double(train_depth{k});
    od_msk=train_odgt{k};
    img=roi{k};
                                                               
    imgR=double(img(:,:,1));
    imgR=imgR-double(min(imgR(:)));
    
    [HSV] = rgb2hsv(img) ;
   
    imgV=double(HSV(:,:,3));
    imgV=imgV-double(min(imgV(:)));
    
    [YCbCr]=rgb2ycbcr(img);
    
    imgY=double(YCbCr(:,:,1));
    imgY=imgY-double(min(imgY(:)));
    
    imgCb=double(YCbCr(:,:,2));
    imgCb=imgCb-double(min(imgCb(:)));
    
    imgCr=double(YCbCr(:,:,3));
    imgCr=imgCr-double(min(imgCr(:)));
    
    
   norm_sz=201;
  

    
    
    
    % compute gradient magnitude and directions
    %grd_sz=9;
    grd_sz=15;
    % find grad map for R channel
     R_map=get_normalized_ftrs( imgR ,inc, grd_sz,w,norm_sz);
     V_map=get_normalized_ftrs( imgV ,inc, grd_sz,w,norm_sz);
     Y_map=get_normalized_ftrs( imgY ,inc, grd_sz,w,norm_sz);
    Cb_map=get_normalized_ftrs( imgCb ,inc, grd_sz,w,norm_sz);
    Cr_map=get_normalized_ftrs( imgCr ,inc, grd_sz,w,norm_sz);
    
 
    
    
   
   
    
   
    
    % for each profile
    c=0;
    for th=1:inc:360
        c=c+1
        
        
        % indexes of the pixels present in current profile
        tmp_idx=idx{th};
        
        % All profiles are defined upto the full length of the ROI
        cp_msk_prfl=cupgt(tmp_idx);
        od_msk_prfl=od_msk(tmp_idx);
        depth_prfl=double(depth_img(tmp_idx));
        depth_prfl=depth_prfl-min(depth_prfl(:));
        depth_prfl=depth_prfl./max(depth_prfl(:));
       
        rmap_prfl=R_map(tmp_idx);
        vmap_prfl=V_map(tmp_idx);
        ymap_prfl=Y_map(tmp_idx);
        cbmap_prfl=Cb_map(tmp_idx);
        crmap_prfl=Cr_map(tmp_idx);
    
      
        
        % find od boundary location from GT
        od_idx=find(od_msk_prfl==0);
        if ~isempty(od_idx)
            od_idx=od_idx(1)-1;
        else
           display('hi OD') 
           od_idx=r;
        end
        % find cp boundary location from GT
         cp_idx=find(cp_msk_prfl==0);
        if ~isempty(cp_idx)
            cp_idx=cp_idx(1)-1;
        else
           display('hi Cup') 
           cp_idx=r;
        end
     
          
          
          
          
        tmp_ftr=[rmap_prfl(od_idx)  vmap_prfl(od_idx) ymap_prfl(od_idx) cbmap_prfl(od_idx) crmap_prfl(od_idx)];
        tmp_ftr=[tmp_ftr  rmap_prfl(cp_idx)  vmap_prfl(cp_idx) ymap_prfl(cp_idx) cbmap_prfl(cp_idx) crmap_prfl(cp_idx)];
        
        % Feature 3: Drop in depth from od to cup 
       tmp_ftr=[tmp_ftr  abs(depth_prfl(od_idx)-depth_prfl(cp_idx))];  
           
           
         
        
        
        
       ftr{c}=[ftr{c}; tmp_ftr];
       
       cp_pos(k,c)=cp_idx;
       od_pos(k,c)=od_idx;
          clear tmp_ftr
    end
        
        
end
% Pairwise feature 2d: adjacent od dist, adjacent cp dist
c=0;
for th=1:inc:360
    c=c+1;
    
    curr_od=od_pos(:,c);
    curr_cp=cp_pos(:,c);
    
    if c<(360/inc)
   next_od=od_pos(:,c+1);
   next_cp=cp_pos(:,c+1);
   else
       next_od=od_pos(:,1);
       next_cp=cp_pos(:,1);
   end
   grd_od=abs(next_od-curr_od);
   grd_cp=abs(next_cp-curr_cp);
  
   
   % learn pairwise term here: even if we do searching over diff no of
   % components, it is always 1 or 2: so we can choose 1(also will prevent overfitting the training set)
        binary_od{c} = gmdistribution.fit(grd_od,1,'Start','randSample','Replicates',5,'CovType','full','SharedCov',false,'Regularize',.001,'Options',options);
        binary_cp{c} = gmdistribution.fit(grd_cp,1,'Start','randSample','Replicates',5,'CovType','full','SharedCov',false,'Regularize',.001,'Options',options);
   
                ftr99=ftr{c};
                %% OD UNARY
        for k1 = 1:5
            obj{k1} = gmdistribution.fit(ftr99(:,1:5),k1,'Start','randSample','Replicates',5,'CovType','full','SharedCov',false,'Regularize',.001,'Options',options);
            AIC(k1)= obj{k1}.AIC;
        end
        [minAIC,numComponents] = min(AIC);
        numComponents
        od_unary{c} = obj{numComponents};
        
        clear k1 obj AIC minAIC numComponents
   
        %% CUP UNARY
 %
        for k1 = 1:5
            obj{k1} = gmdistribution.fit(ftr99(:,6:10),k1,'Start','randSample','Replicates',5,'CovType','full','SharedCov',false,'Regularize',.001,'Options',options);
            AIC(k1)= obj{k1}.AIC;
        end
        [minAIC,numComponents] = min(AIC);
        numComponents
        cp_unary{c} = obj{numComponents};
        
        clear k1 obj AIC minAIC numComponents
   %}     
        %% PAIRWISE DEPTH
         for k1 = 1:5
            obj{k1} = gmdistribution.fit(ftr99(:,end),k1,'Start','randSample','Replicates',5,'CovType','full','SharedCov',false,'Regularize',.001,'Options',options);
            AIC(k1)= obj{k1}.AIC;
        end
        [minAIC,numComponents] = min(AIC);
        numComponents
        pair_depth{c} = obj{numComponents};
        
        clear k1 obj AIC minAIC numComponents
        

      
      
end
% save learnt parameters inside model
model.od_unary=od_unary;
model.cp_unary=cp_unary;
model.binary_od=binary_od;
model.binary_cp=binary_cp;
model.pair_depth=pair_depth;


end
        
        
        
      