function [ model, cx, cy, r] = cup_train( img, cupgt,odgt, depth, inc, norm_sz,w )

% Resize all images to a standard size (201 by 201??) and store centre of
% image in (cx,cy)
sz=norm_sz;

for k=1:numel(img)
   img{k}=imresize(img{k}, [sz sz],'bicubic');
   
    cupgt{k}=cupgt{k}>255*(3/4);
   cupgt{k}=imresize(cupgt{k},  [sz sz],'bicubic');
  
   odgt{k}=odgt{k}>255*(3/4);
   odgt{k}=imresize(odgt{k},  [sz sz],'bicubic');
   
   depth{k}=imresize(depth{k}, [sz sz],'bicubic');
end
cx=ceil(norm_sz/2);
cy=cx;
r=cx-1;

 [model] = train1(depth,cupgt, img,odgt,cx,cy,r,inc,w);

end

