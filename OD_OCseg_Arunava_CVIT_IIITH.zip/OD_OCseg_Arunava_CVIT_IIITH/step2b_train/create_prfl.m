function [ ] = create_prfl( norm_sz,w )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

tmp=zeros(norm_sz,norm_sz);
x1=ceil(norm_sz/2);
y1=x1;
for angle=1:360
    for lineLength=1:(x1-1)
        
        x(lineLength) = round(x1 + lineLength * cosd(angle));
        y(lineLength) = round(y1 + lineLength * sind(angle));        
    end
    tx{angle}=x;
    ty{angle}=y;
    idx{angle}=sub2ind([norm_sz, norm_sz], x, y);
    clear x y
end
save('pts.mat','tx','ty','idx');



%% NEW Addition

%% NEw neighborhood
%f=imread('cameraman.tif');
%f=imresize(f,[norm_sz, norm_sz]);

cx=round(norm_sz/2);
cy=cx;
temp=zeros(norm_sz,norm_sz);
idx77=find(temp==0);
temp(idx77)=idx77;

for angle=1:360
 g=imrotate(temp,-angle+90,'nearest','crop');
 tmp=g(cx-w:cx+w,cy:norm_sz);
 
 
 nbr=tmp(:);
 
  tmp2=uint8(zeros(2*w+1,cx));
 idx98=find(tmp2==0);
 
 
 
 idx9=find(nbr>0 & nbr<(norm_sz*norm_sz));
 
 idx98=idx98(idx9);
 
idx_99{angle}=idx98;
 
 nbr=nbr(idx9);
 idx_nbr{angle}=nbr;
                % check result
                %{
                tmp=uint8(zeros(norm_sz,norm_sz));
                tmp(idx_nbr{angle})=f(idx_nbr{angle});
                figure(1),imshow(tmp,[])
                drawnow
                %}
                %{
                tmp2=uint8(zeros(norm_sz,norm_sz));
                tmp2(idx{angle})=1;
                figure(2),imshow(tmp2,[])
                drawnow
                %}
                %{
                tmp1=uint8(zeros(2*w+1,cx));
               
                tmp1(idx_99{cnt})=f(idx_nbr{cnt});
                 figure(3),imshow(tmp1,[])
                 drawnow
                %}
                
end
save('pts_nbr.mat','idx_99','idx_nbr');


end

