clear all
clc

test_dir='/home/arunava/OD_OCseg_Arunava_CVIT_IIITH/Drishti-GS1_files/Images/';% dir of test img
addpath([pwd '/color_normalization/'])
addpath([pwd '/help_files/'])

files2=dir([test_dir '*.png']);
for k=1:numel(files2)
    k
   f=imread([test_dir files2(k).name]);    
   nm=files2(k).name;
   nm=nm(1:end-4);

   tst_nm{k}=files2(k).name;
   [tst_m1{k},tst_n1{k}, tst_mnx1{k}, tst_mxx1{k}, tst_mny1{k}, tst_mxy1{k}, tst_theta{k}, tst_r{k}, tst_m{k}, tst_n{k}, tst_mnx{k}, tst_mxx{k}, tst_mny{k},tst_mxy{k}, tst_od{k},tst_od_msk{k}]=find_od2( f);  
tst_od{k}=match_img(tst_od{k});
end
display('finished processing test images...')
save('test.mat','tst_nm','tst_m1','tst_n1', 'tst_mnx1', 'tst_mxx1', 'tst_mny1', 'tst_mxy1', 'tst_theta', 'tst_r', 'tst_m', 'tst_n', 'tst_mnx', 'tst_mxx', 'tst_mny','tst_mxy', 'tst_od','tst_od_msk');
