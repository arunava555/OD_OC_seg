function [ theta, r ] = compute_align1( f )

f=double(f(:,:,2));

% smallest circle
    % center
    cx=floor(size(f,1)/2);
    cy=floor(size(f,2)/2);
    % radius
    r=min(cx,cy);
    % clipping
    if cx>r
       d=2*(cx-r); 
       d1=floor(d/2);
       d2=ceil(d/2);
       f=f(d1:end-d2,:);
    end
    if cy>r
        d=2*(cy-r);
        d1=floor(d/2);
       d2=ceil(d/2);
       f=f(:,d1:end-d2);
    end
    
    % create circular gradient mask
     se=strel('disk', r, 0); 
     c_mask=double(getnhood(se));
    % make pixels in circle below half line to -1
     tmp=zeros(size(c_mask,1),size(c_mask,2));
     tmp(r+1:end,:)=1;
     tmp=tmp.*c_mask;
     idx=find(tmp>0);
     c_mask(idx)=-1;
     
     
     % Resize to 25 %
      f=imresize(f,size(c_mask));
      c_mask=imresize(c_mask,.25);
      f=imresize(f,.25);
      
      c=1;
      inc=2;
      for theta=70:inc:110
           tmp_msk=imrotate(c_mask,theta,'crop');
           
            % dot product and sum
            trs=f.*tmp_msk;
            rs(c)=sum(trs(:));
            t(c)=theta;
            c=c+1;
      end
         % convolve with gaussian
        sigma = 2;
        sz = 6*sigma;
        x = linspace(-sz / 2, sz / 2, sz);
        gaussFilter = exp(-x .^ 2 / (2 * sigma ^ 2));
        gaussFilter = gaussFilter / sum (gaussFilter); % normalize
        rs = conv (rs, gaussFilter, 'same');
      
        %
        amax=abs(rs);
        mx_idx=find(amax==max(amax));
        tmp=mx_idx(1);
        mx_idx=t(mx_idx(1));
        
        % GET THE REFLECTION
        mn=min(rs);
        mx=max(rs);
        r=0;
        if abs(mn-rs(tmp))>abs(mx-rs(tmp))
    % reflect and make it left heavy
        r=1;
        end
        
      c=1;  
      for theta=-20:inc:20
           tmp_msk=imrotate(c_mask,theta,'crop');
           
            % dot product and sum
            trs=f.*tmp_msk;
            rs(c)=sum(trs(:));
            t(c)=theta;
            c=c+1;
      end
        amin=abs(rs);
        mn_idx=find(amin==min(amin));
        mn_idx=t(mn_idx(1));
        
        idx1=90-mn_idx;
        idx2=90-mx_idx;
        if(abs(idx1)<abs(idx2))
           theta=idx1; 
        else
            theta=idx2;
        end


        

end

