function [top0]= vesselFactortoSuppress_disk(im, sze, weight) 
%%% To get Vessel location softmap to handle vessel region. For example to
%%% suppress or to enhnace
%%% isotropic enhancment
% %% Default value= size=15 and weight=30;
[m, n,dim]=size(im);
if dim>1
% %     Green 
    im=double(im(:,:,2));
%     % Red
%     im=double(im(:,:,1));
%     disp 'ani_isotropicVesselEnhance: <Extracted Green Channel from the color image >  '
else
    im=double(im);
end

im=medfilt2(im,[3 3]);

se = strel('line',sze,0);
top0=imbothat(im,se);

se = strel('line',sze,45);
top45=imbothat(im,se);

se = strel('line',sze,90);
top90=imbothat(im,se);

se = strel('line',sze,135);
top135=imbothat(im,se);

top0=max(top0,top45);
top0=max(top0,top90);
top0=max(top0,top135);
top0=mat2gray(top0);
top0=top0.*weight;


end
