%%% Test point interpolation
function [boudPtsX boudPtsY regPtsX regPtsY]= getBoundaryPts(x,y,row,col)
flistX= []; flistY=[];

for i=1:size(x,1)-1
    x1= x(i);
    y1= y(i);
    x2= x(i+1);
    y2= y(i+1);
    [lX lY]=fitC(x1,y1,x2,y2);
    flistX= [flistX; lX];
    flistY= [flistY; lY];
end
x1= x(1);
y1= y(1);
x2= x(end);
y2= y(end);
[lX lY]=fitC(x1,y1,x2,y2);
flistX= [flistX; lX];
flistY= [flistY; lY];

mask= zeros(row,col);
for i=1: size(flistX,1);
    mask(flistY(i),flistX(i))=1;
end

mask1= zeros(size(mask,1),size(mask,2));
mask2= zeros(size(mask,1),size(mask,2));
col=size(mask,2);
for i=1: size(mask,1)
    in=0; out=0;
    for j=1:size(mask,2)-2
        if mask(i,j)==0 && mask(i,j+1)==1 && in==0
            in=1;
        end
        if mask(i,col-j)==0 && mask(i,col-j-1)==1
            out=1;
        end
        if in==1
            mask1(i,j)=1;
        end
        if out==1
            mask2(i,col-j)=1;
        end
    end
end
maskx=immultiply(mask1, mask2);

mask3= zeros(size(mask,1),size(mask,2));
mask4= zeros(size(mask,1),size(mask,2));
row=size(mask,1);
for j=1: size(mask,2)
    in=0; out=0;
    for i=1:size(mask,1)-2
        if mask(i,j)==0 && mask(i+1,j)==1 && in==0
            in=1;
        end
        
        if mask(row-i,j)==0 && mask(row-i-1,j)==1
            out=1;
        end
        if in==1
            mask3(i,j)=1;
        end
        if out==1
            mask4(row-i,j)=1;
        end
    end
end
masky= immultiply(mask3, mask4);
final= imadd(maskx,masky);
final=final>=1;

[regPtsX regPtsY]= find(final==1);

se= strel('disk',1);
finalP= imerode(final,se);
final= imsubtract(final, finalP);
[boudPtsX boudPtsY]= find(final==1);


% figure, imshow(final);


%%=======================================
function [listX listY]= fitC(x1,y1,x2,y2)
listX=[]; listY=[];
if x1>x2 && y1>y2
    for x=x2:x1
        for y=y2:y1
            cond= (y-y1)- ((y2-y1)/(x2-x1))* (x-x1);
            if abs(cond)< 1
                listX=[listX; round(x)]; listY=[listY; round(y)];
            end
        end
    end
else if x1>x2
        for x=x2:x1
            for y=y1:y2
                cond= (y-y1)- ((y2-y1)/(x2-x1))* (x-x1);
                if abs(cond)< 1
                    listX=[listX; round(x)]; listY=[listY; round(y)];
                end
            end
        end
    else if y1>y2
            for x=x1:x2
                for y=y2:y1
                    cond= (y-y1)- ((y2-y1)/(x2-x1))* (x-x1);
                    if abs(cond)< 1
                        listX=[listX; round(x)]; listY=[listY; round(y)];
                    end
                end
            end
        else
            for x=x1:x2
                for y=y1:y2
                    cond= (y-y1)- ((y2-y1)/(x2-x1))* (x-x1);
                    if abs(cond)< 1
                        listX=[listX; round(x)]; listY=[listY; round(y)];
                    end
                end
            end
        end
    end
end