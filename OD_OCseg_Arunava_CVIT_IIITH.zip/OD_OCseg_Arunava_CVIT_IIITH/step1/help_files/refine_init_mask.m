function [final]=refine_init_mask(subI, rad)
%%% It refines the intiialisation mask for the active contour model. The
%%% problem that has been seen that when a OD is more like allipse then
%%% circle based initialisation require more number of iteration to
%%% converse. So the idea is modify the initial circle such that for OD
%%% instances we get almost near approximating mask such that no. of
%%% interation almost remain constant for all cases and process can be
%%% speed-up.
%%% subI= color, centric to the location detected by OD localisation module;
% % % submask= if the initial circular mask which need to be modify
%%% subI= respective cropped colour retinal image

centerx= round(size(subI,1)/2); centery= round(size(subI,2)/2);
[px, py]= meshgrid(1:size(subI,1),1:size(subI, 2));
theta=atan2((px-centerx),(py-centery));
radius= round(sqrt((px-centerx).^2+(py-centery).^2));
mask= radius>=rad-20 & radius<2*rad;
% figure, imshow(radius,[]);

%%% To get OD region
red = subI(:,:,1);
red=mat2gray(red);
edgeMap= edge(red,'canny',[0.3 0.6],19);
edgeMap= immultiply(edgeMap,mask);
% [ex ey]= find(edgeMap==1);

radLoc=[]; angleLoc=[];
% figure, imshow(red,[]); hold on;
for i=-pi:pi/18:pi
    [inx, iny]= find(abs(theta-i)<0.01 & edgeMap==1);
    if size(inx,1)~=0
        angleLoc= [angleLoc, theta(inx(1),iny(1))];
        radLoc=[radLoc,radius(inx(1),iny(1))];
    else
        [inx, iny]= find(abs(theta-i)<0.01 & radius==rad);
        angleLoc= [angleLoc, theta(inx(1),iny(1))];
        radLoc=[radLoc,radius(inx(1),iny(1))];
    end
end

% size(angleLoc)
% size(radLoc)

radcycle= [radLoc(1,end-1) radLoc(1,end) radLoc radLoc(1,1) radLoc(1,2)];
radcycle= smooth(radcycle,9);  %% Found 9 better
radcycle= radcycle';

% size(radcycle)
xx=[]; yy=[];
for i=1: size(angleLoc, 2)
    cory=round(centery+ radcycle(i+2)*sin(angleLoc(i)));
    corx=round(centerx+ radcycle(i+2)*cos(angleLoc(i)));
%     plot(cory, corx,'b*');
    xx= [xx; corx]; yy= [yy; cory];    
end
% hold off;

[bx, by, rx, ry]= getBoundaryPts(yy,xx,size(subI,1), size(subI,2));


final= zeros(size(subI,1), size(subI,2));
for i=1: size(rx,1)
    final(rx(i), ry(i))=1;
end

%disp '>> Initialisation of mask is performed ..'



