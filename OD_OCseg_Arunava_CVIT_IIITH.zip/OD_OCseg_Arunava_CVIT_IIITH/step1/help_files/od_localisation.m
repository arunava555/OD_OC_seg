function [locOD, rad]= od_localisation(icolor)
rawimg= imresize(icolor,0.25,'bicubic');
top0= vesselFactortoSuppress_disk(rawimg, 15, 30); %% To get vessel softmap

hsv= rgb2hsv(rawimg);
fmask= hsv(:,:,3)>0.1;
fedge= edge(fmask,'canny');
se= strel('disk',10);
fedge= imdilate(fedge,se,'same');
fedge=fedge>0;

%%% Consider only RED channel 
rawimg= double(mat2gray(rawimg(:,:,1)).*255);
rawimg= imadd(rawimg, top0); %% To eliminate the influence of vessel edges
rawimg= medfilt2(rawimg,[10 10]);

minRad= 35;maxRad= 55; %%% Set to the original

%%% Hough Transform-based intensity-based circle detection
[accum, circen, cirrad] = CircularHough_Grd_G_disk(rawimg, [minRad maxRad],fedge);
accum= mat2gray(accum);
maxval= 0; inx=1;  
for i=1: size(circen,1)
    y= round(circen(i,1)); x= round(circen(i,2)); rad= round(cirrad(i));
    if x-rad>0 && y-rad>0 && x+rad<= size(rawimg,1)&& y+rad<= size(rawimg,2) && ...
            rad<56 && rad>34
        val= sum(sum(rawimg(x-rad:x+rad, y-rad: y+rad)))/(rad*rad);
        if val>maxval && mean2(accum(x-3:x+3,y-3:y+3))>0.4
            maxval= val; inx= i; 
        end
    else
        continue;
    end
    
end
xloc= round(circen(inx,2))*4; yloc=  round(circen(inx,1))*4;
rad= round(cirrad(inx))*4;
%{
 mask= zeros(size(icolor,1),size(icolor,2));
 for i=xloc-rad:xloc+rad
     for j=yloc-rad: yloc+rad
         if sqrt((i-xloc)^2+(j-yloc)^2)<=rad
             if i>0 && i<=size(icolor,1) && j>0 && j<=size(icolor,2)
             mask(i,j)=1;
             end
         else
             continue; 
         end       
     end
 end
%}
locOD(1,1)= xloc; locOD(1,2)=yloc;


