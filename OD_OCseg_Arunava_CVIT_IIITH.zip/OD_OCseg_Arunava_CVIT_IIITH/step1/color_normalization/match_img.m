function [ g ] = match_img(f)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

f1=double(f(:,:,1));f2=double(f(:,:,2));f3=double(f(:,:,3));

load('img_stats.mat')











% map the mean and var of each channel to a particular value
f1=f1-mean(f1(:));
f1=f1./std(f1(:));
f1=f1.*sg1;
f1=f1+avg1;


f2=f2-mean(f2(:));
f2=f2./std(f2(:));
f2=f2.*sg2;
f2=f2+avg2;


f3=f3-mean(f3(:));
f3=f3./std(f3(:));
f3=f3.*sg3;
f3=f3+avg3;


g1(:,:,1)=(f1);
g1(:,:,2)=(f2);
g1(:,:,3)=(f3);
f1=double(f(:,:,1));f2=double(f(:,:,2));f3=double(f(:,:,3));

%{
% hist specification
f1=double(histeq(uint8(f1),h1));
f2=double(histeq(uint8(f2),h2));
f3=double(histeq(uint8(f3),h3));
%}



% map each channel to a particular range [mnx,mxx]
f1=f1-min(f1(:));
f1=f1./max(f1(:));
f1=f1.*(mx1-mn1);
f1=f1+mn1;

f2=f2-min(f2(:));
f2=f2./max(f2(:));
f2=f2.*(mx2-mn2);
f2=f2+mn2;

f3=f3-min(f3(:));
f3=f3./max(f3(:));
f3=f3.*(mx3-mn3);
f3=f3+mn3;




g2(:,:,1)=(f1);
g2(:,:,2)=(f2);
g2(:,:,3)=(f3);


g=uint8((g1+g2)./2);

end

