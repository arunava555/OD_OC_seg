function [ m1, n1, mnx1, mxx1, mny1, mxy1, theta, r, m, n, mnx, mxx, mny, mxy, od, od_msk] =find_od2( f)
%{
m1,n1: size of subI and submask
mnx1,mxx1,mny1,mxy1: position of submask and subI

theta,r: alignment parameter

%}
%% obtain OD mask (approx) for f
[locOD, rad]= od_localisation(f);
cropsize=600;
cx= locOD(1,1); cy= locOD(1,2);
[m, n, ~]=size(f);
%%% Cropping around OD -> Iorg
subI(:,:,1)= f(cx-cropsize:cx+cropsize, cy-cropsize:cy+cropsize,1);
subI(:,:,2)= f(cx-cropsize:cx+cropsize, cy-cropsize:cy+cropsize,2);
subI(:,:,3)= f(cx-cropsize:cx+cropsize, cy-cropsize:cy+cropsize,3);


%%% Refine localization
submask=refine_init_mask(subI, rad); 
submask=submask>0;
[m1, n1]=size(submask);
mnx=cx-cropsize;mxx=cx+cropsize;
mny=cy-cropsize;mxy=cy+cropsize;
%% Get some boundary region+ make the region circular
 [gtx, gty]=find(submask>0);
margin=max((max(gtx)-min(gtx)),(max(gty)-min(gty)));
margin=ceil(.2*margin);

  
   mnx1=min(gtx)-margin;
   mxx1=max(gtx)+margin;
   mny1=min(gty)-margin;
   mxy1=max(gty)+margin;
   d1=mxx1-mnx1;
   d2=mxy1-mny1;
   if d1>d2
      dff=d1-d2;
      dff1=floor(dff/2);
      dff2=ceil(dff/2);
      mny1=mny1-dff1;
      mxy1=mxy1+dff2;
   end
   if d2>d1
       dff=d2-d1;
      dff1=floor(dff/2);
      dff2=ceil(dff/2);
      mnx1=mnx1-dff1;
      mxx1=mxx1+dff2;
   end
%% get alignment parameters for OD   
   od=subI(mnx1:mxx1,mny1:mxy1,:);
   [theta, r]=compute_align1(od);
%% rotate/reflect the original image as well as the mask   
   subI=imrotate(subI,theta,'bicubic','crop');
   submask=imrotate(submask,theta,'bicubic','crop');
   
   
   
   if r==1
      subI=subI(:,end:-1:1,:);
      submask=submask(:,end:-1:1);  
  
   end
   
   %% CROP region of interest: slightly bigger than localiation

   od=subI(mnx1:mxx1,mny1:mxy1,:);
   od_msk=submask(mnx1:mxx1,mny1:mxy1);
  
 
   
   
   
    [xx, yy]= find(od_msk==1);
    cxAbs=mean(xx); cyAbs=mean(yy);

  
                                              
end

